package DecoratorFacade;

public interface Burger {

	public String getDescription();
	public double getCost();
	
}
