package main;

public class MainClass {

	public static void main(String[] args) {
		
		Item tshirt = new Item();
		tshirt.setName("Adidas originals white t-shirt");
		tshirt.setQuantity(2);
		
		Item shoes = new Item();
		shoes.setName("Nike Air Force 1");
		shoes.setQuantity(3);
		
		Item ski = new Item();
		ski.setName("Salomon 2020 ski");
		ski.setQuantity(5);
		
		Person Aleksandar = new Person();
		BuyItem boughtItem = new BuyItem(shoes);
		SellItem soldItem = new SellItem(tshirt);
		BuyItem boughtItem2 = new BuyItem(ski);
		
			
		Aleksandar.takeOrder(boughtItem);
		Aleksandar.takeOrder(soldItem);
		Aleksandar.takeOrder(boughtItem2);
		
		Aleksandar.placeOrders();
		
	}

}
