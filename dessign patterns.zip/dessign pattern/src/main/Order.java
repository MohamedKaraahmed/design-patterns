package main;

public interface Order {
	
	void execute();
}
